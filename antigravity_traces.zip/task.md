# CrisisLink Backend Integration Task List

- `[x]` Step 1: Add network dependencies (`http`) to `pubspec.yaml`
- `[x]` Step 2: Implement dynamic simulation API route `POST /actions/simulate-generic` in FastAPI backend
- `[x]` Step 3: Rebuild `AIService` in `lib/services/ai_service.dart` with actual HTTP requests and emulator-aware URLs
- `[x]` Step 4: Refactor safety monitor UI `lib/features/safety_monitor/safety_monitor_screen.dart` to use `aiServiceProvider`
- `[x]` Step 5: Refactor strategy simulator UI `lib/features/simulator/strategy_simulator_screen.dart` to use `aiServiceProvider`
- `[x]` Step 6: Sync citizen reported incidents with FastAPI background verification pipeline in `lib/features/incidents/create_incident_screen.dart`
- `[x]` Step 7: Verify and run `flutter analyze` to ensure zero compilation or lint errors
- `[x]` Step 8: Set active gcloud project config to `ciro-28820` and enable compute API
- `[x]` Step 9: Configure network firewall ingress rules for port 8000
- `[x]` Step 10: Provision the Ubuntu GCE VM instance (`ciro-backend-vm`)
- `[x]` Step 11: Package and copy files (`app`, `.env.example`, `docker-compose.yml`, `requirements.txt`) to the VM
- `[x]` Step 12: Connect via SSH and bootstrap services (Docker compose, Python packages, Uvicorn)
- `[x]` Step 13: Retrieve VM's public IP and update `lib/services/ai_service.dart` locally
- `[x]` Step 14: Verify and test endpoint connectivity
