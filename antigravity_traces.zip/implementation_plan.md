# CrisisLink GCP VM Deployment & Integration Plan

This plan details the steps required to deploy the CrisisLink Python FastAPI backend, PostgreSQL, and Redis services to a Google Compute Engine VM instance within GCP project `ciro-28820` (under account `ali.flutter4733@gmail.com`). We will configure network firewalls for public secure ingress, boot the containerized infrastructure on a VM, and update the local Flutter app's telemetry layers to connect to the live cloud IP.

## User Review Required

> [!IMPORTANT]
> **Compute Engine API Activation**: This deployment requires the `compute.googleapis.com` service to be enabled in your GCP project. We will request execution of `gcloud services enable compute.googleapis.com` which you will need to approve in the CLI.
> **Deployment Scope**: Per your explicit instructions, we will **only** deploy the `app` folder, `.env.example`, `docker-compose.yml`, and `requirements.txt` to the VM.
> **VPC Firewall Ingress**: We will create a GCP firewall rule named `allow-fastapi-ingress` allowing TCP port `8000` traffic from all IPs (`0.0.0.0/0`) so the mobile application can communicate with the live AI forecast pipeline.
> **Gemini API Key**: The `.env.example` file contains your real `GEMINI_API_KEY`. On the VM, we will copy `.env.example` directly to `.env` to load this key into uvicorn and database layers.

## Open Questions

> [!NOTE]
> None. The requirements are fully detailed. We will proceed directly with the steps below once approved.

## Proposed Changes

We will execute the deployment and integration across the following areas:

---

### 1. GCP Project & Services Setup
- Set active gcloud project configuration to `ciro-28820`:
  ```powershell
  gcloud config set project ciro-28820
  ```
- Enable the Google Compute Engine API:
  ```powershell
  gcloud services enable compute.googleapis.com --project=ciro-28820
  ```

---

### 2. Network Firewall Rule (Ingress & Egress)
- Create a VPC firewall rule to allow ingress TCP traffic on port `8000` (FastAPI REST server) to all VM instances tagged with `fastapi-backend`:
  ```powershell
  gcloud compute firewall-rules create allow-fastapi-ingress `
      --project=ciro-28820 `
      --direction=INGRESS `
      --priority=1000 `
      --network=default `
      --action=ALLOW `
      --rules=tcp:8000 `
      --source-ranges=0.0.0.0/0 `
      --target-tags=fastapi-backend
  ```
- Default GCP egress rules already allow outbound traffic, ensuring the VM can reach Gemini APIs, Google Maps services, and news sources.

---

### 3. Google Compute Engine VM Provisioning
- Provision a Compute Engine VM instance named `ciro-backend-vm` with Ubuntu 22.04 LTS, matching the `e2-medium` machine type (2 vCPUs, 4GB RAM) to support parallel execution of Docker and Python uvicorn:
  ```powershell
  gcloud compute instances create ciro-backend-vm `
      --project=ciro-28820 `
      --zone=us-central1-a `
      --machine-type=e2-medium `
      --image-project=ubuntu-os-cloud `
      --image-family=ubuntu-2204-lts `
      --tags=fastapi-backend `
      --metadata=startup-script="sudo apt-get update && sudo apt-get install -y docker.io docker-compose python3-pip python3-venv"
  ```

---

### 4. Code Packaging & VM Ingestion
- Upload the specified folders and configuration files directly to the VM instance using `gcloud compute scp`:
  ```powershell
  # Create remote directory on VM
  gcloud compute ssh ciro-backend-vm --zone=us-central1-a --project=ciro-28820 --command="mkdir -p ~/ciro-deployment"

  # Copy folder and files
  gcloud compute scp --recurse c:\Users\alias\Desktop\ciro\app ciro-backend-vm:~/ciro-deployment/app --zone=us-central1-a --project=ciro-28820
  gcloud compute scp c:\Users\alias\Desktop\ciro\.env.example ciro-backend-vm:~/ciro-deployment/.env.example --zone=us-central1-a --project=ciro-28820
  gcloud compute scp c:\Users\alias\Desktop\ciro\docker-compose.yml ciro-backend-vm:~/ciro-deployment/docker-compose.yml --zone=us-central1-a --project=ciro-28820
  gcloud compute scp c:\Users\alias\Desktop\ciro\requirements.txt ciro-backend-vm:~/ciro-deployment/requirements.txt --zone=us-central1-a --project=ciro-28820
  ```

---

### 5. VM Services Bootstrap & Server Launch
- Establish an SSH session and run setup instructions to run Docker Compose and launch the FastAPI server:
  - Copy environment variables: `cp ~/ciro-deployment/.env.example ~/ciro-deployment/.env`
  - Start database and caching containers: `sudo docker-compose -f ~/ciro-deployment/docker-compose.yml up -d`
  - Install python requirements: `pip install -r ~/ciro-deployment/requirements.txt`
  - Launch uvicorn service hosting the REST API:
    ```bash
    nohup uvicorn app.main:app --host 0.0.0.0 --port 8000 > ~/uvicorn.log 2>&1 &
    ```

---

### 6. Local Flutter Integration
- Retrieve the VM's public external IP:
  ```powershell
  gcloud compute instances describe ciro-backend-vm --zone=us-central1-a --project=ciro-28820 --format="get(networkInterfaces[0].accessConfigs[0].natIP)"
  ```
- Modify the base URL configuration in the Flutter app to point directly to the VM's public IP address.

#### [MODIFY] [ai_service.dart](file:///c:/Users/alias/Desktop/ciro/lib/services/ai_service.dart)
- Replace `http://localhost:8000` and emulator routing with the newly provisioned remote VM public IP:
  ```dart
  String get _baseUrl => 'http://<VM_EXTERNAL_IP>:8000';
  ```

---

## Verification Plan

### Automated Tests
- Run `flutter analyze` to ensure clean compilation.
- Test endpoint health from the local machine using raw HTTP:
  ```powershell
  Invoke-RestMethod -Uri "http://<VM_EXTERNAL_IP>:8000/"
  ```

### Manual Verification
- Deploy and launch the Flutter app on Chrome/desktop or phone, select Strategy Simulator or safety routing, and verify it contacts the VM cloud endpoint and receives real Gemini-generated outcomes.
